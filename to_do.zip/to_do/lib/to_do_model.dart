import 'package:hive/hive.dart';

class Todo {
  String title;
  bool isCompleted;

  Todo({
    required this.title,
    this.isCompleted = false,
  });

  // Serialization methods
  factory Todo.fromMap(Map<String, dynamic> map) {
    return Todo(
      title: map['title'] as String,
      isCompleted: map['isCompleted'] as bool,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'isCompleted': isCompleted,
    };
  }
}

class TodoAdapter extends TypeAdapter<Todo> {
  @override
  final int typeId = 0;

  @override
  Todo read(BinaryReader reader) {
    final map = Map<String, dynamic>.from(reader.readMap());
    return Todo.fromMap(map);
  }

  @override
  void write(BinaryWriter writer, Todo obj) {
    writer.writeMap(obj.toMap());
  }
}
