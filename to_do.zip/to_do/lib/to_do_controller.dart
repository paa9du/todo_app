import 'package:get/get.dart';
import 'package:to_do/hive_service.dart';
import 'package:to_do/to_do_model.dart';

class TodoController extends GetxController {
  var todos = <Todo>[].obs;

  final HiveService _hiveService = HiveService();

  @override
  void onInit() {
    todos.value = _hiveService.allTodos;
    super.onInit();
  }

  void addTodoItem(Todo todo) {
    _hiveService.addTodoItem(todo);
    todos.add(todo);
  }

  void toggleTodoStatus(int index) {
    var todo = todos[index];
    todo.isCompleted = !todo.isCompleted;
    _hiveService.updateTodoItem(index, todo);
    todos[index] = todo;
  }

  void deleteTodoItem(int index) {
    _hiveService.deleteTodoItem(index);
    todos.removeAt(index);
  }
}
