import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:to_do/to_do_controller.dart';
import 'package:to_do/to_do_model.dart';
import 'package:to_do/todo_item.dart';

class HomeView extends StatelessWidget {
  final TodoController todoController = Get.put(TodoController());

  @override
  Widget build(BuildContext context) {
    var todoTitleController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Center(
          child: Text('To-Do App'),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: todoTitleController,
                    decoration: InputDecoration(
                      hintText: 'Add a new task',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: BorderSide(
                          color: Colors.blue,
                          width: 2.0,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8.0),
                        borderSide: BorderSide(
                          color: Colors.blue,
                          width: 2.0,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 8.0),
                IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () {
                    if (todoTitleController.text.isNotEmpty) {
                      todoController.addTodoItem(
                        Todo(
                          title: todoTitleController.text,
                        ),
                      );
                      todoTitleController.clear();
                    }
                  },
                ),
              ],
            ),
          ),
          Expanded(
            child: Obx(() => ListView.builder(
                  itemCount: todoController.todos.length,
                  itemBuilder: (context, index) {
                    var todo = todoController.todos[index];
                    return TodoItem(
                      todo: todo,
                      onToggle: () => todoController.toggleTodoStatus(index),
                      onDelete: () => todoController.deleteTodoItem(index),
                    );
                  },
                )),
          ),
        ],
      ),
    );
  }
}
