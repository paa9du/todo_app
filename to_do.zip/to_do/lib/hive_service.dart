import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:to_do/to_do_model.dart';

class HiveService {
  static const String todoBoxName = 'todoBox';

  Future<void> init() async {
    final appDocumentDir = await getApplicationDocumentsDirectory();
    Hive.init(appDocumentDir.path);
    await Hive.openBox<Todo>(todoBoxName);
  }

  Box<Todo> get todoBox => Hive.box<Todo>(todoBoxName);

  void addTodoItem(Todo todo) {
    todoBox.add(todo);
  }

  void updateTodoItem(int index, Todo todo) {
    todoBox.putAt(index, todo);
  }

  void deleteTodoItem(int index) {
    todoBox.deleteAt(index);
  }

  List<Todo> get allTodos => todoBox.values.toList();
}
